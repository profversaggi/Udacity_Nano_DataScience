The iPython NoteBook Contains the entirety and the core of this documented Machine Learning project: Table of Contents, Working Code, Background, Methodology, Testing, Results Summary and Questions & Answers. It is meant to be read top to bottom but the Table of Contents will link back and forth to all of the major areas of this project. It includes a working copy of the tester.py code as well for inclusions sake.


The python code poi_id.py only contains a the minimal code to satifisy the requirements of the runnable model, the core, breath and depth of experiments, analysis, results, etc are contained in the iPython Notebook.


To get a clear idea of the overall strategy of this project, peruse the Table of Contents carefully, then link to the key parts for proper vetting of each process in question.

Test Run the Code - The tester code has been integrated into this NB and can be run for each calssifier evaluated. The summary results are available as a courtesy to the reader.