IMPORTANT
For the Reader who is only interested in the Documentation Questions and Answers Section, please use the link to teh  Documentation Questions and Answers Section, which effectively takes a 150 page read down to a 5 or 7 page read, which might be preferred for some.

The majority of this iPtyhon NB is the explicit calculations, processes, and methodologies used to generate the summary information contained in the Documentation Questions and Answers Section and can be ignored for the most part. The summary information should be sufficient for evaluating the strategies employed and summary results obtained without having to get into the details. Links are provided where appropriate 
if needed. 


The iPython NoteBook Contains the entirety and the core of this documented Machine Learning project: Table of Contents, Working Code, Background, Methodology, Testing, Results Summary and Questions & Answers. It is meant to be read top to bottom but the Table of Contents will link back and forth to all of the major areas of this project. It includes a working copy of the tester.py code as well for inclusions sake.


The python code poi_id.py only contains a the minimal code to satifisy the requirements of the runnable model, the core, breath and depth of experiments, analysis, results, etc are contained in the iPython Notebook.


To get a clear idea of the overall strategy of this project, peruse the Table of Contents carefully, then link to the key parts for proper vetting of each process in question.

Test Run the Code - The tester code has been integrated into this NB and can be run for each calssifier evaluated. The summary results are available as a courtesy to the reader.